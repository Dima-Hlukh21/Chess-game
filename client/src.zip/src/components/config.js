
import socketio from "socket.io-client";






  

export const SOCKET_URL = 'ws://localhost:3333'
